import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner number = new Scanner(System.in);
        int number1 = number.nextInt();
        System.out.println((int)(number1 * 0.5));
    }
}